using System;
using BodyPoseEstimation.Core;

namespace BodyPoseEstimation.MVVM.ViewModel
{
    class DiscoveryViewModel : ObservableObject
    {
        public DiscoveryViewModel()
        {
            
        }
    }
}