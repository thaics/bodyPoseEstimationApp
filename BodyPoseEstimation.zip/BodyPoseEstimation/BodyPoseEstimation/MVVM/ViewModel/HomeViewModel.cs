using System;
using BodyPoseEstimation.Core;

namespace BodyPoseEstimation.MVVM.ViewModel
{
    class HomeViewModel : ObservableObject
    {
        public HomeViewModel()
        {
            
        }
    }
}