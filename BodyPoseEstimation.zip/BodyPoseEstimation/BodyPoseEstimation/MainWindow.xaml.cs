﻿using Python.Included;
using Python.Runtime;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Diagnostics;

namespace BodyPoseEstimation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_MouseDown( object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }

        static async Task downloadPython(string[] args)
        {
            Installer.InstallPath = Path.GetFullPath(".");
            Trace.WriteLine(Path.GetFullPath("."));
            // see what the installer is doing
            Installer.LogMessage += Console.WriteLine;

            Trace.WriteLine("installing python ");
            // install the embedded python distribution
            await Installer.SetupPython();

            Trace.WriteLine("installing pip");
            // install pip3 for package installation
            Installer.TryInstallPip();

            Trace.WriteLine("installing libarries");
            // download and install Spacy from the internet
            Installer.PipInstallModule("mediapipe");
            Installer.PipInstallModule("cv2");

            Trace.WriteLine("Initalizing");
            // ok, now use pythonnet from that installation
            PythonEngine.Initialize();

            // call Python's sys.version to prove we are executing the right version
            dynamic sys = PythonEngine.ImportModule("sys");
            Trace.WriteLine("### Python version:\n\t" + sys.version);

            // call os.getcwd() to prove we are executing the locally installed embedded python distribution
            dynamic os = PythonEngine.ImportModule("os");
            Trace.WriteLine("### Current working directory:\n\t" + os.getcwd());
            Trace.WriteLine("### PythonPath:\n\t" + PythonEngine.PythonPath);

            Console.ReadKey();
        }
    }
}
